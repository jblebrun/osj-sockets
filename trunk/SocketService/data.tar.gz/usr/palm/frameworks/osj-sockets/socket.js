var Socket = function() {
	this.socketURI = "palm://info.opensource.jason.services.socket/";	
	this.id = null;
	this.state = "unconnected";
	this.readHandler = null;
	this.clients = [];
}

Socket.prototype.startserver = function(host, port, callback) {
	  maxConnections = params.maxConnections || 1;
      Mojo.Controller.serviceRequest(this.socketURI, {
        method: "open",
        parameters: {
            host: host,
            port: port, 
            server: true,
            maxConnections: maxConnections
        },
        onSuccess: function(r) {
            this.state = "connected";
            this.id = r.id;
            if(typeof callback === "function") {
                callback();
            }
        },
        onFailure:  function(r) {
            this.state = "error";
            if(typeof callback === "function") {
                callback();
            }
        }
    }); 
};

Socket.prototype.connect = function(host, port, callback) {
	
	chunkSize = params.chunkSize || null;
	
	Mojo.Controller.serviceRequest(this.socketURI, {
		method: "open",
		parameters: {
			host: host,
			port: port, 
			server: server,
			chunkSize: chunkSize, 
			maxConnections: maxConnections
		},
		onSuccess: function(r) {
			this.state = "connected";
			this.id = r.id;
			if(typeof callback === "function") {
				callback();
			}
		},
		onFailure:  function(r) {
			this.state = "error";
			if(typeof callback === "function") {
                callback();
            }
		}
	});	
};

Socket.prototype.startReading = function(handler) {
    if(typeof handler !== "function") {
		throw "Invalid socket read handler";
	}
	
	if(this.state !== "connected") {
		throw "Socket not connected";
	}
	
	
	Mojo.Controller.serviceRequest(this.socketURI, {
		method: "read",
		parameters: {
			id: this.id,
			subscribe: true
		},
		onSuccess: function(r) {
			if(r.data !== undefined) {
			    handler();
			} else {
				this.stopReading();
			}
			
			
		}.bind(this),
		onFailure: function(r) {
			
		}.bind(this)
	});
	
}

Socket.prototype.stopReading = function() {
    Mojo.Controller.serviceRequest(this.socketURI, {
        method: "read",
        parameters: {
            id: this.id,
            subscribe: false
        },
        onSuccess: function(r) {
            if(r.data !== undefined) {
                
            }
            
        },
        onFailure: function(r) {
            
        }
    });
}


Socket.prototype.write = function(data, callback) {
    if(this.id == null || this.state !== "connected") {
		throw "Socket not connected";		
	}
	
	Mojo.Controller.serviceRequest(this.socketURI, {
        method: "write",
        parameters: {
            id: this.id,
            data: data
        },
        onSuccess: function(r) {
            callback();
        },
        onFailure: function(r) {
            
        }
    });
	
	
}
